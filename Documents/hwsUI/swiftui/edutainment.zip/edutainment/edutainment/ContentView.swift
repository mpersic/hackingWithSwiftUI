//
//  ContentView.swift
//  edutainment
//
//  Created by COBE on 18/04/2021.
//

import SwiftUI

struct QuestionView: View {
    var questionNumber: String
    var questionText: String
    
    var body: some View {
        Text(questionNumber)
        Text(questionText)
    }
}
struct selectPracticeNumberView: View {
    @State private var selectedNumber = 0
    var body: some View {
        Form
        {
            Stepper("Which number do you want", value: $selectedNumber, in: 1...12)
            Text("You choose \(selectedNumber)")
        }
    }
    
}

struct ContentView: View {
    
    @State private var currentQuestion = 0
    var questionNumberChoices = ["5", "10", "15", "20", "All"]
    @State private var answer = ""
    @State private var numberOfQuestions = "5"
    @State private var selectedNumber = Int.random(in: 1...12)
    @State private var gameIsActive = false
    @State private var playAgain = false
    @State private var userScore = 0
    @State private var broj = Int.random(in: 1...12)
    @State var generatedQuestions = [Question]()
    var body: some View {
        Group {
            if !gameIsActive{
                NavigationView{
                    VStack{
                        Form {
                            Section(header: Text("Which number do you want to practice")){
                                Stepper("You choose number \(selectedNumber)", value: $selectedNumber, in: 1...12)
                            }
                        }
                        Section(header: Text("Please select the number of questions you want")){
                                Picker("", selection: $numberOfQuestions) {
                                    ForEach(questionNumberChoices, id: \.self) {
                                        //Text(self.questionNumberChoices[$0])
                                        Text($0)
                                    }
                                    .pickerStyle(SegmentedPickerStyle())
                                }
                            }
                        Form{
                            Text("You selected: \(numberOfQuestions) questions")
                            Button("Play"){
                                self.gameIsActive.toggle()
                                var range: Int = Int(self.numberOfQuestions) ?? 144
//                                ForEach (0 ..< range)  {_ in
//                                    var randomNumber = Int.random(in: 1...12)
//                                    var text = "How much is \(self.selectedNumber)*\(randomNumber)"
//                                    var answer = String(selectedNumber * randomNumber)
//                                    self.generatedQuestions.append(Question(text: text, answer: answer))
//                                    }
                            }
                        }
                        
                    }
                    .navigationBarTitle("Edutainment")
                }
            }
            else {
                NavigationView{
                    VStack{
                        let questionCount = Int(numberOfQuestions) ?? 144 // 12*12
                        if questionCount != 144 {
                            ForEach(0 ..< questionCount) { number in
                                if number == questionCount - 1, currentQuestion == number {
                                    Text("your score is \(userScore)")
                                    Button("Play again?") {
                                        self.playAgain.toggle()
                                        broj = Int.random(in: 1...12)
                                        currentQuestion = 0
                                        answer = ""
                                        userScore = 0
                                    }
                                    .animation(.easeOut)
                                    .background(Color.green)
                                    Button("New settings") {
                                        self.gameIsActive.toggle()
                                    }
                                    .background(Color.orange)
                                }
                                
                                else if currentQuestion == number
                                {
                                    QuestionView(questionNumber: "question number \(number + 1)",
                                                 questionText: "how much is \(selectedNumber)*\(broj)")
                                    TextField("Enter your number", text: $answer)
                                    Text("your score is \(userScore)")
                                    Button("Next question"){
                                        
                                        if(selectedNumber*broj == Int(answer)){
                                            userScore += 1
                                        }
                                        
                                        broj = Int.random(in: 1...12)
                                        currentQuestion += 1
                                        answer = ""
                                    }
                                    .background(Color.green)
                                }
                            }
                        }
                        else {
                            
                        }
                        
                        
                    }
                    .navigationBarTitle("Edutainment")
                }
            }
        }
    }
}


struct Question {
    var text: String
    var answer: String
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
